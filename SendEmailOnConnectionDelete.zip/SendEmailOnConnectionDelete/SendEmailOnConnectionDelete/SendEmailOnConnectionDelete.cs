﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Text;
using System.Xml.Linq;
using System.Linq;
using System.Xml;

namespace SendEmailOnConnectionDelete
{
    public class SendEmailOnConnectionDelete : IPlugin
    {
        private XmlDocument _pluginConfiguration;
        public StringBuilder Trace { get; set; }
        private string emailTemplateName { get; set; }

        public SendEmailOnConnectionDelete(string unsecureConfig, string secureConfig)
        {

            //throw new InvalidPluginExecutionException("unsecureConfig = "+ unsecureConfig + "___secureConfig = "+ secureConfig);
            //throw new InvalidPluginExecutionException("unsecureConfig = "+ unsecureConfig );

            if (string.IsNullOrEmpty(unsecureConfig))
            {
                throw new InvalidPluginExecutionException("Unsecure configuration missing.");
            }
            //_pluginConfiguration = new XmlDocument();
            //_pluginConfiguration.LoadXml(unsecureConfig);
            emailTemplateName = unsecureConfig.Trim();
            //throw new InvalidPluginExecutionException(emailTemplateName);
        }

        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            //IOrganizationService crmService = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService crmService = serviceFactory.CreateOrganizationService(null);
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Trace = new StringBuilder();

            try
            {
                //-- Connected From = record1id //-- Lookup

                Guid connectionId = Guid.Empty;
                if (context.InputParameters["Target"] is EntityReference)
                {
                    EntityReference entRef = (EntityReference)context.InputParameters["Target"];
                    connectionId = entRef.Id;
                }

                Guid fromConnectionId = Guid.Empty;
                if (connectionId != Guid.Empty)
                {
                    EntityCollection entColl = GetConnectionFields(connectionId, crmService);

                    trace.Trace("connectionId = " + connectionId);
                    trace.Trace("Count = " + entColl.Entities.Count.ToString());

                    EntityReference entRefConnectedTo = null;
                    EntityReference entRefRoleTo = null;
                    EntityReference entRefConnectedFrom = null;

                    foreach (Entity entConnection in entColl.Entities)
                    {
                        if (entConnection.Contains("record2id") && entConnection["record2id"] != null)
                        {
                            entRefConnectedTo = (EntityReference)entConnection["record2id"];
                        }

                        if (entConnection.Contains("record2roleid") && entConnection["record2roleid"] != null)
                        {
                            entRefRoleTo = (EntityReference)entConnection["record2roleid"];
                        }

                        if (entConnection.Contains("record1id") && entConnection["record1id"] != null)
                        {
                            entRefConnectedFrom = (EntityReference)entConnection["record1id"];
                        }
                    }

                    if (entRefConnectedTo != null && entRefConnectedFrom != null && entRefRoleTo != null)
                    {
                        //string templateTitle = GetConfigDataString(_pluginConfiguration, "EmailTemplateName");

                        //emailTemplateName = emailTemplateName.Replace(" ", "X");
                        //throw new InvalidPluginExecutionException(emailTemplateName);

                        string templateTitle = emailTemplateName;//"Send Email To Contact";
                        //string templateTitle = "Send Email To Contact";
                        EntityReference entRefContactFullName = (EntityReference)entColl.Entities[0]["record2id"];
                        string roleName = entRefRoleTo.Name;
                        string leadName = entRefConnectedFrom.Name;
                        SendEmailToContact(templateTitle, entRefConnectedTo, roleName, leadName, crmService);
                    }
                }
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw ex;
            }
        }

        public static string GetConfigDataString(XmlDocument doc, string label)
        {
            return GetValueNode(doc, label);
        }
        private static string GetValueNode(XmlDocument doc, string key)
        {
            XmlNode node = doc.SelectSingleNode(String.Format("Settings/setting[@name='{0}']", key));
            if (node != null)
            {
                return node.SelectSingleNode("value").InnerText;
            }
            return string.Empty;
        }

        public EntityCollection GetConnectionFields(Guid connectionId, IOrganizationService crmService)
        {
            Guid fromConnectionId = Guid.Empty;
            string fetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='connection'>
                                <attribute name='record1id' />
                                <attribute name='record2id' />
                                <attribute name='record1roleid' />
                                <attribute name='record2roleid' />
                                <attribute name='record1objecttypecode' />
                                <attribute name='record2objecttypecode' />
                                <filter type='and'>
                                  <condition attribute='connectionid' operator='eq' uitype='connection' value='{" + connectionId + @"}' />
                                    <condition attribute='record2roleid' operator='not-null'/>
                                </filter>
                              </entity>
                            </fetch>";
            EntityCollection entColl = crmService.RetrieveMultiple(new FetchExpression(fetchXML));
            return entColl;
        }

        public void SendEmailToContact(string templateTitle, EntityReference entRefContactFullName, string roleName, string leadName, IOrganizationService crmService)
        {
            EmailTemplate emailTemplate = GetEmailTemplate(templateTitle, crmService);
            Guid emailId = CreateEmail(emailTemplate, entRefContactFullName, roleName, leadName, crmService);
            //SendEmailResponse response = SendEmail(emailId, crmService);
        }

        public SendEmailResponse SendEmail(Guid emailId, IOrganizationService crmService)
        {
            SendEmailResponse response = null;
            SendEmailRequest sendRequest = new SendEmailRequest();
            sendRequest.EmailId = emailId;
            sendRequest.TrackingToken = "";
            sendRequest.IssueSend = true;
            try
            {
                response = (SendEmailResponse)crmService.Execute(sendRequest);
            }
            catch (Exception ex)
            {
                ;
            }
            return response;
        }

        public EmailTemplate GetEmailTemplate(string templateTitle, IOrganizationService crmService)
        {
            //Outage Alert Email Notification Template
            EmailTemplate emailTemplate = new EmailTemplate();
            string fetchXmlString = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='template'>
                                    <attribute name='templateid' />
                                    <attribute name='body' />
                                    <attribute name='subject' />
                                    <filter type='and'>
                                      <condition attribute='title' operator='eq' value='" + templateTitle + @"' />
                                    </filter>
                                  </entity>
                                </fetch>";
            EntityCollection entColl = crmService.RetrieveMultiple(new FetchExpression(fetchXmlString));
            if (entColl != null && entColl.Entities.Count > 0)
            {
                Entity entity = entColl.Entities[0];
                emailTemplate.EmailTemplateId = entity.Id;
                emailTemplate.Subject = GetDataFromXml(entity["subject"].ToString());
                emailTemplate.Body = GetDataFromXml(entity["body"].ToString());
            }
            return emailTemplate;
        }

        private string GetDataFromXml(string value)
        {
            if (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }
            XDocument document = XDocument.Parse(value);
            XNode node = document.Descendants().Elements().Last().LastNode;
            string nodeText = node.ToString().Replace("<![CDATA[", string.Empty).Replace("]]>", string.Empty);
            return nodeText;
        }

        public Guid CreateEmail(EmailTemplate emailTemplate, EntityReference entRefContactFullName, string roleName, string leadName, IOrganizationService crmService)
        {
            Entity[] to = GetContact(entRefContactFullName);
            Entity entEmail = new Entity("email");
            entEmail["subject"] = emailTemplate.Subject;
            entEmail["description"] = string.Format(emailTemplate.Body, entRefContactFullName.Name, roleName, leadName);
            entEmail["to"] = to;
            //entEmail["from"] = fromParty;
            Guid emailId = crmService.Create(entEmail);
            return emailId;
        }

        public Entity[] GetContact(EntityReference entRefContact)
        {
            EntityCollection to = new EntityCollection();
            Entity toParty = new Entity("activityparty");
            toParty["partyid"] = entRefContact;
            to.Entities.Add(toParty);
            Entity[] arrayTo = to.Entities.ToArray();
            return arrayTo;
        }
    }
}
